package arithmetic_calculator;

import java.util.Scanner;

public class calculator {
	
	public static final void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("First number:");
		int numberA = scanner.nextInt();
		System.out.println("Second number:");
		int numberB = scanner.nextInt();
		System.out.println("Operator you want to use:");
		scanner.nextLine();
		String operation = scanner.nextLine();
		
		double result = 0;
		if (operation.equals("add")) {
			AddOperation add = new AddOperation();
			add.setA(numberA);
			add.setB(numberB);
			result = add.getResult();
		} else if (operation.equals("subtract")) {
			SubtractOperation subtract = new SubtractOperation();
			subtract.setA(numberA);
			subtract.setB(numberB);
			result = subtract.getResult();
		} else if (operation.equals("multiply")) {
			MultiplyOperation multiply = new MultiplyOperation();
			multiply.setA(numberA);
			multiply.setB(numberB);
			result = multiply.getResult();
		} else if (operation.equals("divide")) {
			DivideOperation divide = new DivideOperation();
			divide.setA(numberA);
			divide.setB(numberB);
			result = divide.getResult();
		} else {
			System.out.println("Did not understand operation");
		}
		
		System.out.println("The answer is:");
		System.out.println(result);
	}

}
