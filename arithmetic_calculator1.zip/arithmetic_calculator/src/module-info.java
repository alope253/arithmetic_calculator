module arithmetic_calculator {
}